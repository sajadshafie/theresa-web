import config from "../config/Globals";
import FormData from "form-data";
// import moment from 'moment-jalaali';

module.exports = {
  getSearchItems: (successCallback, errorCallback, where, string) => {
    config
      .axiosHandle()
      .get(`/base/${where}/${string}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        console.warn(error.response);
        errorCallback(error);
      });
  },
  processSignup: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/signup", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  processNewPrescription: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/newprescription", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processNewTransfer: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/newtransfer", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processNewCard: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/ph/createcard", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processGetSq: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/ph/fc", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  processGetAddressess: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/user/getaddress", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  processNewAddress: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/user/address", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processNewPharmacy: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/create/pharmacy", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  processCreatePaymnent: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/ph/cp", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processDeleteCard: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/ph/deletecard", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getPrescriptionList: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/prescriptions", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  getUserInfo: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/user/info", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  getPrescriptionItemList: (successCallback, errorCallback, prescription) => {
    config
      .axiosHandle()
      .get(`/prescription/items/${prescription}`)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getPrescriptionStatusList: (successCallback, errorCallback, prescription) => {
    config
      .axiosHandle()
      .get(`/prescription/status/${prescription}`)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  processDeletePrescriptionItem: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/delete/prescriptionitem", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processCompleteProfileFirst: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/user/completeprofile/first", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processCompleteProfileTwo: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/user/completeprofile/two", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processCompleteProfileAll: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/user/completeprofile/all", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processConfirm: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("/confirm", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  uploadFile: (
    media,
    successCallback,
    errorCallback,
    progressCallback = () => {}
  ) => {
    var formData = new FormData();
    formData.append("file", media);

    const configAxios = {
      onUploadProgress: (progressEvent) => {
        var percentCompleted = Math.round(
          (progressEvent.loaded * 100) / progressEvent.total
        );
        progressCallback(percentCompleted);
        console.log(percentCompleted);
      },
    };

    config
      .axiosUploadHandle()
      .post("/uploadprocess", formData, configAxios)
      .then((response) => {
        successCallback(response);
        // alert('imageUri');
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  getBaseApiData: (successCallback, errorCallback) => {
    const citylist = config.axiosHandle().get(`/city/list`, {});
    const districtlist = config.axiosHandle().get(`/district/list`, {});
    const facilitylist = config.axiosHandle().get(`/facility/list`, {});
    const qualificationlist = config
      .axiosHandle()
      .get(`/qualification/list`, {});
    const accountlist = config.axiosHandle().get(`/account/list`, {});

    Promise.all([
      citylist,
      facilitylist,
      qualificationlist,
      accountlist,
      districtlist,
    ])
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getPropertyList: (successCallback, errorCallback, accountid) => {
    config
      .axiosHandle()
      .get(`/account/property/${accountid}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getDistrictList: (successCallback, errorCallback, cityid) => {
    config
      .axiosHandle()
      .get(`/city/district/${cityid}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getHouse: (successCallback, errorCallback, house) => {
    config
      .axiosHandle()
      .get(`house/${house}`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getComplex: (successCallback, errorCallback, house) => {
    config
      .axiosHandle()
      .get(`complex/${house}`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  getUserHouses: (successCallback, errorCallback, page = 0) => {
    config
      .axiosHandle()
      .get(`user/manage/house/list/${page}`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getUserFavs: (successCallback, errorCallback, page = 0) => {
    config
      .axiosHandle()
      .get(`user/manage/favs/${page}`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getUserComplexFavs: (successCallback, errorCallback, page = 0) => {
    config
      .axiosHandle()
      .get(`user/manage/complexfavs/${page}/`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  saveUserData: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("user/manage/info", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  saveVendorData: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("user/manage/vendor/", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  updateVendorData: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .patch("user/manage/vendor/", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getUserData: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get(`user/manage/info`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getUserVendorList: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get(`user/manage/vendor/list/0`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processDeleteHouse: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .delete("user/manage/house/", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processAddToFav: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("user/manage/act", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processNewHouse: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("user/manage/house/", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processUpdateHouse: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .patch("user/manage/house/", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processFilterHouse: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("filter", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  GetCategoryList: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get(`cl`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  GetCategoryVideos: (successCallback, errorCallback, cat, page) => {
    config
      .axiosHandle()
      .get(`ghb/${cat}/${page}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  GetChannelVideos: (successCallback, errorCallback, token, page) => {
    config
      .axiosHandle()
      .get(`ch/${token}/${page}`, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  GetHomeChannelList: (successCallback, errorCallback, page = 0) => {
    config
      .axiosHandle()
      .get(`chl/${page}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  GetChannel: (successCallback, errorCallback, token, page = 0) => {
    config
      .axiosHandle()
      .get(`ch/${token}/${page}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  processAct: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("user/act", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  confirmMobile: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("user/confirm", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  processLoginBarcode: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("v0.1/core/login_with_token", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  driverCancel: (
    requestId,
    body,
    successCallback,
    errorCallback = () => {}
  ) => {
    config
      .axiosHandle()
      .patch(`v0.1/logistic/driver_cancel/${requestId}/`, body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  driverConfirm: (
    requestId,
    body,
    successCallback,
    errorCallback = () => {}
  ) => {
    config
      .axiosHandle()
      .patch(`v0.1/logistic/driver_confirm/${requestId}/`, body)
      .then((response) => {
        console.log(response);
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  orderRequest: (
    requestId,
    body,
    successCallback,
    errorCallback = () => {}
  ) => {
    config
      .axiosHandle()
      .patch(`v0.1/logistic/order-request/${requestId}/`, body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  confirmInvoices: (invoiceId, successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .patch(`v0.1/accounting/confirm_invoice/${invoiceId}/`, { status: 5 })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  updateRealtimeAttrs: (body, successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .patch("v0.1/logistic/driver_update_realtime_attrs/", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  //orfilter_pickup_driver_idORdelivery_driver_id

  getDriverInvoices: (successCallback, errorCallback, driverId, extra) => {
    config
      .axiosHandle()
      .get(
        `v0.1/sales/bills_without_details/?page_size=25&driver_id=${driverId}${extra}&order_by=order_in_list`,
        {}
      )
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  getHolidays: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get("v0.1/core/constants", {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  patchDeliverGarment: (
    invoiceDetailId,
    successCallback,
    errorCallback = () => {}
  ) => {
    config
      .axiosHandle()
      .patch(`v0.1/sales/deliver_garment/${invoiceDetailId}/?of=driver`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  putCustomer: (
    customerId,
    params,
    successCallback,
    errorCallback = () => {}
  ) => {
    config
      .axiosHandle()
      .put(`v0.1/sales/customers/${customerId}/`, params)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  payInvoiceAccount: (
    invoiceId,
    params,
    successCallback,
    errorCallback = () => {}
  ) => {
    config
      .axiosHandle()
      .post(`v0.1/accounting/pay-invoice/${invoiceId}/`, params)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  addGarmentAndInvoiceDetail: (params, successCallback, errorCallback) => {
    config
      .axiosHandle()
      .post("v0.1/sales/garments/", params.garment)
      .then((responsegarment) => {
        if (responsegarment) {
          const invoicedetail = {
            garment: responsegarment.data.id,
            invoice: params.invoicedetail.invoice,
            service: params.invoicedetail.service,
            description: params.invoicedetail.description, // [0],
            cost: params.invoicedetail.cost,
            extra_cost: params.invoicedetail.extra_cost,
          };

          config
            .axiosHandle()
            .post("v0.1/accounting/invoice_details/", invoicedetail)
            .then((response) => {
              successCallback(response);
            })
            .catch((error) => {
              errorCallback(error);
            });
        }
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  cancelInvoiceDetail: (invocieDetailId, successCallback, errorCallback) => {
    config
      .axiosHandle()
      .patch(`v0.1/accounting/cancel_invoice_detail/${invocieDetailId}/`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  driverUnavailable: (requestId, params, successCallback, errorCallback) => {
    config
      .axiosHandle()
      .patch(`v0.1/logistic/driver_unavailable/${requestId}/`, params)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  editGarmentAndInvoiceDetail: (
    garmentid,
    invocieDetailId,
    params,
    successCallback,
    errorCallback
  ) => {
    config
      .axiosHandle()
      .patch(`v0.1/sales/garments/${garmentid}/`, params.garment)
      .then((responsegarment) => {
        if (responsegarment) {
          const invoicedetail = {
            garment: responsegarment.data.id,
            invoice: params.invoicedetail.invoice,
            service: params.invoicedetail.service,
            description: params.invoicedetail.description, // [0],
            cost: params.invoicedetail.cost,
            extra_cost: params.invoicedetail.extra_cost,
          };

          config
            .axiosHandle()
            .patch(
              `v0.1/accounting/invoice_details/${invocieDetailId}/`,
              invoicedetail
            )
            .then((response) => {
              successCallback(response);
            })
            .catch((error) => {
              errorCallback(error);
            });
        }
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  getCustomerBy: (successCallback, errorCallback, filter = {}) => {
    const buff = [];
    if (filter) {
      if (filter.id) {
        buff.push(`filter_id=${String(filter.id)}`);
      }
      if (filter.mobile) {
        buff.push(`filter_mobile=${tools.convertToEnglish(filter.mobile)}`);
      }
      if (filter.tel) {
        buff.push(`filter_tel=${filter.tel}`);
      }
      if (filter.customer_name) {
        buff.push(`filter_user__last_name=${filter.customer_name}`);
      }
    }
    config
      .axiosHandle()
      .get(`v0.1/sales/customers/?represent_address=True&${buff.join("&")}`)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
    //buff.push(`filter_is_active=True`);
  },

  addMassiveInvoiceDetail: (
    invoiceId,
    arr,
    successCallback,
    errorCallback = () => {}
  ) => {
    config
      .axiosHandle()
      .post(`v0.1/accounting/massive_invoice_detail/${invoiceId}`, {
        invoice_details: arr,
      })
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  postDescriptions: (params, successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .post("v0.1/sales/descriptions/", params)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  postBill: (params, successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .post("v0.1/sales/bills/?of=driver", params)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  patchBill: (requestId, params, successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .patch(`v0.1/sales/bills/${requestId}/?of=driver`, params)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  patchDeliverGarments: (id, successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .patch(`v0.1/sales/deliver_garments/${id}/?of=driver`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getServices: (callback) => {
    config.axiosHandle().get("v0.1/sales/services/", (response) => {
      callback(response);
    });
  },
  getDescriptionCats: (successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .get("v0.1/sales/description_cats/")
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getDescriptions: (successCallback, errorCallback = () => {}) => {
    config
      .axiosHandle()
      .get("v0.1/sales/descriptions/")
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getServerData: (callback) => {
    const services = config.axiosHandle().get("v0.1/sales/services/");
    const products = config.axiosHandle().get("v0.1/sales/products/");
    const colors = config.axiosHandle().get("v0.1/sales/colors/");
    const patterns = config.axiosHandle().get("v0.1/sales/patterns/");
    const holidays = config.axiosHandle().get("v0.1/core/constants");
    const productscost = config
      .axiosHandle()
      .get("v0.1/sales/products_services_cost/");
    const descriptions = config.axiosHandle().get("v0.1/sales/descriptions/");

    const description_cats = config
      .axiosHandle()
      .get("v0.1/sales/description_cats/");

    const product_categories = config
      .axiosHandle()
      .get("v0.1/sales/product_categories/");

    const driver = config.axiosHandle().get("v0.1/logistic/drivers/", {});
    Promise.all([
      services,
      products,
      product_categories,
      driver,
      colors,
      patterns,
      productscost,
      holidays,
      descriptions,
      description_cats,
    ]).then((values) => {
      callback(values);
    });
  },

  getProducts: (callback) => {
    config.axiosHandle().get("v0.1/sales/products/", (response) => {
      callback(response);
    });
  },
  getProductCategories: (callback) => {
    config.axiosHandle().get("v0.1/sales/product_categories/", (response) => {
      callback(response);
    });
  },
  getBill: (successCallback, errorCallback, invoiceId) => {
    config
      .axiosHandle()
      .get(`v0.1/sales/bills/?filter_invoice__id=${invoiceId}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getBillRequest: (successCallback, errorCallback, requestId) => {
    config
      .axiosHandle()
      .get(`v0.1/sales/bills/?filter_id=${requestId}`, {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getDrivers: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get("v0.1/logistic/drivers/", {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  loadUserOrders: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get("v0.1/sales/new_request/", {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getCustomerBalance: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get("v0.1/accounting/get_balance", {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getCustomerProfile: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get("v0.1/sales/customer-profile", {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  getMobileConstants: (successCallback, errorCallback) => {
    config
      .axiosHandle()
      .get("v0.1/core/mobile_constants", {})
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  requestConfirmEmail: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("v0.1/core/request-confirm-email/", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  putCustomerProfile: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .put("v0.1/sales/customer-profile", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },

  generateResetPassword: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("v0.1/core/reset_password_request", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  resetPassword: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("v0.1/core/reset_password", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  confirmPass: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("v0.1/core/confirm", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
  signupUser: (successCallback, errorCallback, body) => {
    config
      .axiosHandle()
      .post("v0.1/core/register", body)
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        errorCallback(error);
      });
  },
};
