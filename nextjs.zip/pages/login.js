import { useEffect, useState } from "react";
import Head from "next/head";
import Image from "next/image";
import { Form, Input, Button, Radio } from "antd";
import {
  AsYouType,
  isValidPhoneNumber,
  parsePhoneNumberFromString,
} from "libphonenumber-js";

import styles from "../styles/auth.module.css";

import RootLayout from "../components/base/rootLayout";

import FormAuth from "../components/base/formAuth";
import Link from "next/link";

export default function Login() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [mobile, setMobile] = useState("");
  const [errorMobile, setErrorMobile] = useState(false);
  const [errorPassword, setErrorPassword] = useState(false);

  const [password, setPassword] = useState("");

  const onPress = () => {
    setErrorMobile(false);
    setErrorPassword(false);

    let errorMode = false;

    const phoneNumber = parsePhoneNumberFromString(mobile, "CA");

    let mobileFormat = null;
    if (!phoneNumber || phoneNumber.number.length < 10) {
      errorMode = true;
      setErrorMobile(true);
    } else {
      mobileFormat = phoneNumber.number;
    }

    if (password.length < 6) {
      errorMode = true;
      setErrorPassword(true);
    }

    if (errorMode) {
      return;
    }

    setLoading(true);
    const postData = {
      mobile: mobileFormat,
      password,
    };

    console.log(postData);

    setTimeout(() => {
      setLoading(false);
    }, 1500);
  };

  return (
    <RootLayout title="Teresa" description="Teresa">
      <FormAuth
        bottomLinkAction="/signup"
        description="Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
      nonummy nibh euismod tincidunt"
      >
        <Form
          form={form}
          layout="vertical"

          // onValuesChange={onRequiredTypeChange}
          // requiredMark={requiredMark}
        >
          <Form.Item
            label="Phone"
            required
            hasFeedback={errorMobile}
            validateStatus={errorMobile ? "error" : ""}
            // tooltip="This is a required field"
          >
            <Input
              size="large"
              value={mobile}
              onChange={(v) => {
                const phoneNumber = parsePhoneNumberFromString(
                  v.target.value,
                  "CA"
                );
                if (phoneNumber) {
                  if (phoneNumber.nationalNumber.length > 10) {
                    return;
                  }
                }

                setMobile(new AsYouType("CA").input(v.target.value));
              }}
              placeholder=""
            />
          </Form.Item>
          <Form.Item
            required
            hasFeedback={errorPassword}
            validateStatus={errorPassword ? "error" : ""}
            label="Password"
            // tooltip="At Least 5 Characters"
          >
            <Input
              onChange={(v) => {
                setPassword(v.target.value);
              }}
              type="password"
              size="large"
              placeholder=""
            />
          </Form.Item>
          <Form.Item>
            <Link href="/forgetpass">
              <a href="">Forgot password?</a>
            </Link>
          </Form.Item>

          <Form.Item className={styles.centerButton}>
            <Button
              loading={loading}
              onClick={() => onPress()}
              size="large"
              type="primary"
              className="buttonDefault"
            >
              Sign in
            </Button>
          </Form.Item>
        </Form>
      </FormAuth>
    </RootLayout>
  );
}
