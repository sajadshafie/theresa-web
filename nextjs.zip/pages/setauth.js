import { useState } from "react";
import Head from "next/head";
import Image from "next/image";
import { Form, Input, Button, Radio, Row, Col } from "antd";

import styles from "../styles/auth.module.css";

import RootLayout from "../components/base/rootLayout";

import FormAuth from "../components/base/formAuth";

export default function SetAuth() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  return (
    <RootLayout reverseMode title="Teresa" description="Teresa">
      <FormAuth
        title="Sign up"
        description="Please enter your password"
        bottomText="Already a user? "
        bottomLinkText="Sign in"
        bottomLinkAction="/login"
        marginMode
      >
        <Form
          form={form}
          layout="vertical"

          // onValuesChange={onRequiredTypeChange}
          // requiredMark={requiredMark}
        >
          <Form.Item
            label="Password"
            required
            tooltip="This is a required field"
          >
            <Input type="password" size="large" placeholder="" />
          </Form.Item>
          <Form.Item
            required
            label="Re-enter Password"
            // tooltip="This is a required field"
          >
            <Input type="password" size="large" placeholder="" />
          </Form.Item>

          <Form.Item className={styles.centerButton}>
            <Button
              loading={loading}
              onClick={() => setLoading(true)}
              size="large"
              type="primary"
              className="buttonDefault"
            >
              submit
            </Button>
          </Form.Item>
        </Form>
      </FormAuth>
    </RootLayout>
  );
}
