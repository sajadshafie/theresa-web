import { useState } from "react";
import Head from "next/head";
import Image from "next/image";
import { Form, Input, Button, Radio } from "antd";

import {
  AsYouType,
  isValidPhoneNumber,
  parsePhoneNumberFromString,
} from "libphonenumber-js";
import styles from "../styles/auth.module.css";

import RootLayout from "../components/base/rootLayout";

import FormAuth from "../components/base/formAuth";

export default function ForgetPass() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const [mobile, setMobile] = useState("");
  const [errorMobile, setErrorMobile] = useState(false);

  const onPress = () => {
    setErrorMobile(false);

    let errorMode = false;

    const phoneNumber = parsePhoneNumberFromString(mobile, "CA");

    let mobileFormat = null;
    if (!phoneNumber || phoneNumber.number.length < 10) {
      errorMode = true;
      setErrorMobile(true);
    } else {
      mobileFormat = phoneNumber.number;
    }

    if (errorMode) {
      return;
    }

    setLoading(true);
    const postData = {
      mobile: mobileFormat,
    };

    setTimeout(() => {
      setLoading(false);
      Router.push("/confirm");
    }, 1500);
  };
  return (
    <RootLayout reverseMode title="Teresa" description="Teresa">
      <FormAuth
        title="Forget Password"
        description="Please enter your phone"
        bottomText="Already a user? "
        bottomLinkText="Sign in"
        bottomLinkAction="/login"
        marginMode
      >
        <Form
          form={form}
          layout="vertical"

          // onValuesChange={onRequiredTypeChange}
          // requiredMark={requiredMark}
        >
          <Form.Item
            label="Phone"
            required
            // tooltip="This is a required field"
          >
            <Input
              size="large"
              value={mobile}
              onChange={(v) => {
                const phoneNumber = parsePhoneNumberFromString(
                  v.target.value,
                  "CA"
                );
                if (phoneNumber) {
                  if (phoneNumber.nationalNumber.length > 10) {
                    return;
                  }
                }

                setMobile(new AsYouType("CA").input(v.target.value));
              }}
              placeholder=""
            />
          </Form.Item>

          <Form.Item className={styles.centerButton}>
            <Button
              disabled={mobile.length < 14}
              loading={loading}
              onClick={() => onPress()}
              size="large"
              type="primary"
              className="buttonDefault"
            >
              Next
            </Button>
          </Form.Item>
        </Form>
      </FormAuth>
    </RootLayout>
  );
}
